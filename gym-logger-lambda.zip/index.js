// lambda_code/index.js
// Import AWS SDK v3 modules
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, PutCommand, UpdateCommand, DeleteCommand, QueryCommand } = require('@aws-sdk/lib-dynamodb');

// Import library for generating unique IDs
const { v4: uuidv4 } = require('uuid');

// Configure AWS SDK v3 DynamoDB DocumentClient
const client = new DynamoDBClient({}); // Initialize DynamoDBClient
const dynamoDb = DynamoDBDocumentClient.from(client); // Create DocumentClient from standard client

// Retrieve the table name from environment variables defined in the CloudFormation template
const tableName = process.env.TABLE_NAME; 

// Entry point for the Lambda function
// This function handles incoming API Gateway requests and interacts with DynamoDB
// The event parameter contains details about the request
exports.handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    let body;
    let statusCode = 200;
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*', // Allow all origins for CORS
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
    };

    try {
        // Extract userId from path parameters.
        const userId = event.pathParameters ? event.pathParameters.userId : null;
        // Extract id from path parameters.
        const itemId = event.pathParameters ? event.pathParameters.id : null;

        // Parse the request body for POST/PUT requests
        if (event.body) {
            try {
                body = JSON.parse(event.body);
            } catch (parseError) {
                console.error('JSON Parse Error:', parseError);
                throw new Error('Invalid JSON in request body.');
            }
        }

        // Reroutes the request based on the HTTP method
        switch (event.httpMethod) {
            case 'POST':
                // Create a new fitness entry
                // Throw an error if userId is not provided
                if (!userId) {
                    throw new Error('User ID is required for POST requests.');
                }
                // Throw an error if type and date is not provided
                if (!body || !body.type || !body.date) {
                    throw new Error('Request body must contain type and date.');
                }
                // Generate a unique ID for the new item
                const newId = uuidv4(); 
                // Parameters for entering data into DynamoDB
                // The item will include userId, id, and other properties from the body
                const putParams = {
                    TableName: tableName,
                    Item: {
                        userId: userId,
                        id: newId,
                        timestamp: new Date().toISOString(), 
                        ...body
                    },
                };
                // Insert the new item into DynamoDB using SDK v3 PutCommand
                await dynamoDb.send(new PutCommand(putParams));
                body = { message: 'Item created successfully!', id: newId };
                statusCode = 201; // Set status code for successful creation
                break;
        
            case 'GET':
                // Get fitness entries
                // If userId is not provided, throw an error
                if (!userId) {
                    throw new Error('User ID is required for GET requests.');
                }
                // Get a single item by userId and id
                if (itemId) {
                    const getParams = {
                        TableName: tableName,
                        Key: {
                            userId: userId,
                            id: itemId,
                        },
                    };
                    // Get the item from DynamoDB using SDK v3 GetCommand
                    const result = await dynamoDb.send(new GetCommand(getParams));
                    // If the item is not found, return a 404 status code otherwise return the item
                    if (!result.Item) {
                        statusCode = 404;
                        body = { message: 'Item not found.' };
                    } else {
                        body = result.Item;
                    }
                }
                else {
                    // Get all items for a specific userId
                    const queryParams = {
                        TableName: tableName,
                        KeyConditionExpression: 'userId = :hkey',
                        ExpressionAttributeValues: { // Start with initial values for KeyConditionExpression
                            ':hkey': userId,
                        },
                        ExpressionAttributeNames: {} // Initialize for potential FilterExpression
                    };

                    // Conditionally add FilterExpression based on 'type' query parameter
                    if (event.queryStringParameters && event.queryStringParameters.type) {
                        const entryType = event.queryStringParameters.type;

                        queryParams.FilterExpression = '#type = :typeValue';
                        queryParams.ExpressionAttributeNames['#type'] = 'type';
                        queryParams.ExpressionAttributeValues[':typeValue'] = entryType; // Add to existing values
                    }

                    // Query items from DynamoDB using SDK v3 QueryCommand
                    const result = await dynamoDb.send(new QueryCommand(queryParams));
                    body = result.Items;
                }
                break;

            case 'PUT':
                // Update an existing fitness entry
                if (!userId || !itemId) {
                    throw new Error('User ID and Item ID are required for PUT requests.');
                }
                if (!body || Object.keys(body).length === 0) {
                    throw new Error('Request body is empty or invalid for update.');
                }

                // Build UpdateExpression and ExpressionAttributeValues dynamically
                // This allows updating multiple attributes without hardcoding them
                const updateExpressionParts = [];
                const expressionAttributeValues = {};
                const expressionAttributeNames = {}; // For handling reserved keywords in attribute names
                for (const key in body) {
                    // Don't allow updating primary keys or timestamp
                    if (key !== 'userId' && key !== 'id' && key !== 'timestamp' && body.hasOwnProperty(key)) { 
                        // Use placeholder names for attributes to avoid issues with reserved keywords
                        const placeholderName = `#${key}`; 
                        const placeholderValue = `:${key}`;
                        updateExpressionParts.push(`${placeholderName} = ${placeholderValue}`);
                        expressionAttributeValues[placeholderValue] = body[key];
                        expressionAttributeNames[placeholderName] = key;
                    }
                }

                if (updateExpressionParts.length === 0) {
                    throw new Error('No valid attributes to update in the request body.');
                }

                const updateParams = {
                    TableName: tableName,
                    Key: {
                        userId: userId,
                        id: itemId,
                    },
                    UpdateExpression: 'SET ' + updateExpressionParts.join(', '),
                    ExpressionAttributeValues: expressionAttributeValues,
                    ReturnValues: 'ALL_NEW', 
                };

                // Only include ExpressionAttributeNames if there are any to map
                if (Object.keys(expressionAttributeNames).length > 0) {
                    updateParams.ExpressionAttributeNames = expressionAttributeNames;
                }

                try {
                    // Update the item in DynamoDB using SDK v3 UpdateCommand
                    const result = await dynamoDb.send(new UpdateCommand(updateParams));
                    body = { message: 'Item updated successfully!', updatedItem: result.Attributes };
                } catch (updateError) {
                    if (updateError.name === 'ConditionalCheckFailedException') { // SDK v3 uses .name for error codes
                        statusCode = 404;
                        body = { message: 'Item not found for update.' };
                    } else {
                        throw updateError; // Re-throw other errors
                    }
                }
                break;

            case 'DELETE':
                // Delete a fitness entry
                if (!userId || !itemId) {
                    throw new Error('User ID and Item ID are required for DELETE requests.');
                }
                const deleteParams = {
                    TableName: tableName,
                    Key: {
                        userId: userId,
                        id: itemId,
                    },
                };
                // Delete the item from DynamoDB using SDK v3 DeleteCommand
                await dynamoDb.send(new DeleteCommand(deleteParams));
                body = { message: 'Item deleted successfully!' };
                break;

            case 'OPTIONS':
                // Handle CORS preflight requests
                statusCode = 200;
                body = {}; // Empty body for OPTIONS
                break;

            default:
                throw new Error(`Unsupported HTTP method: ${event.httpMethod}`);
        }
    } catch (err) {
        statusCode = err.message.includes('required') || err.message.includes('Invalid JSON') || err.message.includes('attributes to update') ? 400 : 500;
        body = { error: err.message };
        console.error('Error processing request:', err);
    } finally {
        // Ensure body is stringified for API Gateway
        body = JSON.stringify(body);
    }

    return {
        statusCode,
        body,
        headers,
    };
};
